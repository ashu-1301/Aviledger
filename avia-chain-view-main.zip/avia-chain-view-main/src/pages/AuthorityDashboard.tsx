import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import FlightCard from "@/components/FlightCard";
import { useNavigate } from "react-router-dom";
import { Shield, Settings, Bell, RefreshCw, AlertTriangle, CheckCircle, Users, Plane } from "lucide-react";

// Mock flight data
const mockFlights = [
  {
    flightNumber: "AA1234",
    aircraft: "Boeing 737-800",
    route: { from: "LAX", to: "JFK" },
    status: "normal" as const,
    altitude: 35000,
    speed: 580,
    engineTemp: 650,
    passengers: 152,
    crew: {
      pilot: "Capt. Smith",
      coPilot: "F.O. Johnson", 
      flightAttendants: 4
    },
    estimatedArrival: "14:30 EST"
  },
  {
    flightNumber: "UA5678",
    aircraft: "Airbus A320",
    route: { from: "ORD", to: "SFO" },
    status: "warning" as const,
    altitude: 8500,
    speed: 450,
    engineTemp: 720,
    passengers: 134,
    crew: {
      pilot: "Capt. Davis",
      coPilot: "F.O. Wilson",
      flightAttendants: 3
    },
    estimatedArrival: "16:45 PST"
  },
  {
    flightNumber: "DL9012",
    aircraft: "Boeing 777-300ER",
    route: { from: "ATL", to: "LHR" },
    status: "critical" as const,
    altitude: 12000,
    speed: 920,
    engineTemp: 850,
    passengers: 298,
    crew: {
      pilot: "Capt. Brown",
      coPilot: "F.O. Taylor",
      flightAttendants: 8
    },
    estimatedArrival: "09:15 GMT"
  }
];

const AuthorityDashboard = () => {
  const navigate = useNavigate();
  const [selectedFlight, setSelectedFlight] = useState<string | null>(null);
  
  const normalFlights = mockFlights.filter(f => f.status === 'normal').length;
  const warningFlights = mockFlights.filter(f => f.status === 'warning').length;
  const criticalFlights = mockFlights.filter(f => f.status === 'critical').length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/30 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary-glow rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Authority Dashboard</h1>
                <p className="text-xs text-muted-foreground">Full System Access • Data Modification Enabled</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" size="sm">
                <Bell className="w-4 h-4 mr-2" />
                Alerts
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="flight-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Flights</p>
                  <p className="text-2xl font-bold">{mockFlights.length}</p>
                </div>
                <Plane className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="flight-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Normal Status</p>
                  <p className="text-2xl font-bold text-success">{normalFlights}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-success" />
              </div>
            </CardContent>
          </Card>

          <Card className="flight-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Warnings</p>
                  <p className="text-2xl font-bold text-warning">{warningFlights}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-warning" />
              </div>
            </CardContent>
          </Card>

          <Card className="flight-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Critical</p>
                  <p className="text-2xl font-bold text-destructive">{criticalFlights}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-destructive" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Flight Monitoring</h2>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="bg-success/10 text-success border-success/30">
              <div className="w-2 h-2 bg-success rounded-full mr-2 animate-pulse"></div>
              Live Data Stream
            </Badge>
            <Button variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Flight Grid */}
        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {mockFlights.map((flight) => (
            <FlightCard
              key={flight.flightNumber}
              flight={flight}
              onClick={() => navigate(`/flight/${flight.flightNumber}`)}
              showDetails={false}
            />
          ))}
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <Card className="flight-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5" />
                <span>Authority Actions</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <Button variant="outline" className="h-auto py-4 flex-col space-y-2">
                  <Users className="w-6 h-6" />
                  <span>Manage Crew</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col space-y-2">
                  <AlertTriangle className="w-6 h-6" />
                  <span>Emergency Protocols</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col space-y-2">
                  <Shield className="w-6 h-6" />
                  <span>System Security</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AuthorityDashboard;