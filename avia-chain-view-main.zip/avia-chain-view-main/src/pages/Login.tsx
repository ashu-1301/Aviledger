import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Users, Eye, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const Login = () => {
  const { type } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [credentials, setCredentials] = useState({ username: "", password: "" });

  const loginConfig = {
    authority: {
      title: "Authority Login",
      icon: Shield,
      description: "Access all flight data with modification privileges",
      redirectTo: "/dashboard/authority"
    },
    employee: {
      title: "Employee Login", 
      icon: Users,
      description: "View-only access to flight monitoring systems",
      redirectTo: "/dashboard/employee"
    },
    public: {
      title: "Public Access",
      icon: Eye,
      description: "Basic flight status and schedule information",
      redirectTo: "/dashboard/public"
    }
  };

  const config = loginConfig[type as keyof typeof loginConfig];
  const IconComponent = config?.icon || Shield;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!credentials.username || !credentials.password) {
      toast({
        title: "Authentication Required",
        description: "Please enter your credentials",
        variant: "destructive"
      });
      return;
    }

    // Simulate authentication
    toast({
      title: "Authentication Successful",
      description: `Welcome to AviLedger ${type} dashboard`,
    });
    
    navigate(config.redirectTo);
  };

  if (!config) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Invalid Access Type</h1>
          <Button onClick={() => navigate("/")} variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate("/")}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
          
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <IconComponent className="w-8 h-8 text-primary" />
          </div>
          
          <h1 className="text-2xl font-bold mb-2">{config.title}</h1>
          <p className="text-muted-foreground text-sm">{config.description}</p>
        </div>

        <Card className="flight-card">
          <CardHeader>
            <CardTitle className="text-center">AviLedger Access</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={credentials.username}
                  onChange={(e) => setCredentials(prev => ({ ...prev, username: e.target.value }))}
                  className="bg-background/50"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={credentials.password}
                  onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                  className="bg-background/50"
                />
              </div>

              <Button type="submit" className="w-full">
                Access System
              </Button>

              <div className="space-y-3">
                <div className="text-center">
                  <div className="text-xs text-muted-foreground bg-muted/20 px-3 py-2 rounded">
                    🔒 Blockchain-secured authentication
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="text-xs text-muted-foreground bg-primary/5 border border-primary/20 px-3 py-2 rounded">
                    <div className="font-medium text-primary mb-1">Demo Credentials</div>
                    <div>Username: <span className="font-mono">demo</span></div>
                    <div>Password: <span className="font-mono">password</span></div>
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Login;