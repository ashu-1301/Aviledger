import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plane, Users, Clock, MapPin, Thermometer, Gauge, BarChart3 } from "lucide-react";

// Extended mock flight data
const getFlightData = (flightNumber: string) => {
  const flights: Record<string, any> = {
    "AA1234": {
      flightNumber: "AA1234",
      aircraft: "Boeing 737-800",
      route: { from: "LAX", to: "JFK" },
      status: "normal",
      altitude: 35000,
      speed: 580,
      engineTemp: 650,
      passengers: 152,
      crew: {
        pilot: "Capt. John Smith",
        coPilot: "F.O. Sarah Johnson",
        flightAttendants: 4
      },
      estimatedArrival: "14:30 EST",
      departureTime: "11:45 PST",
      flightTime: "5h 45m",
      fuelRemaining: "12,500 lbs",
      coordinates: { lat: 39.8283, lng: -98.5795 }
    },
    "UA5678": {
      flightNumber: "UA5678", 
      aircraft: "Airbus A320",
      route: { from: "ORD", to: "SFO" },
      status: "warning",
      altitude: 8500,
      speed: 450,
      engineTemp: 720,
      passengers: 134,
      crew: {
        pilot: "Capt. Michael Davis",
        coPilot: "F.O. Emily Wilson",
        flightAttendants: 3
      },
      estimatedArrival: "16:45 PST",
      departureTime: "13:30 CST",
      flightTime: "4h 15m",
      fuelRemaining: "8,900 lbs",
      coordinates: { lat: 41.2524, lng: -95.9980 }
    },
    "DL9012": {
      flightNumber: "DL9012",
      aircraft: "Boeing 777-300ER", 
      route: { from: "ATL", to: "LHR" },
      status: "critical",
      altitude: 12000,
      speed: 920,
      engineTemp: 850,
      passengers: 298,
      crew: {
        pilot: "Capt. Robert Brown",
        coPilot: "F.O. Lisa Taylor",
        flightAttendants: 8
      },
      estimatedArrival: "09:15 GMT",
      departureTime: "22:30 EST",
      flightTime: "8h 45m",
      fuelRemaining: "45,200 lbs",
      coordinates: { lat: 51.4700, lng: -0.4543 }
    }
  };
  
  return flights[flightNumber];
};

const FlightDetail = () => {
  const { flightNumber } = useParams();
  const navigate = useNavigate();
  const flight = getFlightData(flightNumber || "");

  if (!flight) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Flight Not Found</h1>
          <Button onClick={() => navigate(-1)} variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical': return 'status-critical';
      case 'warning': return 'status-warning';
      default: return 'status-normal';
    }
  };

  const getMetricStatus = (type: string, value: number) => {
    switch (type) {
      case 'altitude':
        return value < 10000 ? 'critical' : value < 15000 ? 'warning' : 'normal';
      case 'speed':
        return value > 900 ? 'critical' : value > 800 ? 'warning' : 'normal';
      case 'engineTemp':
        return value > 800 ? 'critical' : value > 700 ? 'warning' : 'normal';
      default:
        return 'normal';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/30 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-3">
                <Plane className="w-6 h-6 text-primary" />
                <div>
                  <h1 className="text-xl font-bold font-mono">{flight.flightNumber}</h1>
                  <p className="text-xs text-muted-foreground">{flight.aircraft}</p>
                </div>
              </div>
            </div>
            <Badge className={`px-4 py-2 ${getStatusColor(flight.status)} border text-sm`}>
              {flight.status.toUpperCase()}
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        {/* Route Overview */}
        <Card className="flight-card mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="w-5 h-5" />
              <span>Flight Route</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between text-lg">
              <div className="text-center">
                <div className="text-3xl font-bold font-mono mb-2">{flight.route.from}</div>
                <div className="text-sm text-muted-foreground">Departure: {flight.departureTime}</div>
              </div>
              <div className="flex-1 mx-8 flex items-center">
                <div className="flex-1 border-t-2 border-dashed border-primary/30"></div>
                <Plane className="w-6 h-6 text-primary mx-4" />
                <div className="flex-1 border-t-2 border-dashed border-primary/30"></div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold font-mono mb-2">{flight.route.to}</div>
                <div className="text-sm text-muted-foreground">Arrival: {flight.estimatedArrival}</div>
              </div>
            </div>
            <div className="text-center mt-4 text-muted-foreground">
              Flight Time: {flight.flightTime}
            </div>
          </CardContent>
        </Card>

        {/* Real-time Metrics */}
        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <Card className="flight-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="w-5 h-5" />
                <span>Altitude</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-4xl font-mono font-bold mb-2 ${getStatusColor(getMetricStatus('altitude', flight.altitude))}`}>
                {flight.altitude.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">feet</div>
              <div className="mt-3 text-xs">
                {flight.altitude < 10000 ? "⚠️ Low altitude alert" : 
                 flight.altitude < 15000 ? "⚡ Ascending/Descending" : 
                 "✅ Cruising altitude"}
              </div>
            </CardContent>
          </Card>

          <Card className="flight-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Gauge className="w-5 h-5" />
                <span>Ground Speed</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-4xl font-mono font-bold mb-2 ${getStatusColor(getMetricStatus('speed', flight.speed))}`}>
                {flight.speed}
              </div>
              <div className="text-sm text-muted-foreground">mph</div>
              <div className="mt-3 text-xs">
                {flight.speed > 900 ? "🚨 High speed warning" : 
                 flight.speed > 800 ? "⚡ Above normal speed" : 
                 "✅ Normal speed"}
              </div>
            </CardContent>
          </Card>

          <Card className="flight-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Thermometer className="w-5 h-5" />
                <span>Engine Temp</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-4xl font-mono font-bold mb-2 ${getStatusColor(getMetricStatus('engineTemp', flight.engineTemp))}`}>
                {flight.engineTemp}°
              </div>
              <div className="text-sm text-muted-foreground">Fahrenheit</div>
              <div className="mt-3 text-xs">
                {flight.engineTemp > 800 ? "🔥 Critical temperature" : 
                 flight.engineTemp > 700 ? "🌡️ High temperature" : 
                 "✅ Normal temperature"}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Crew and Passenger Information */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="flight-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-5 h-5" />
                <span>Crew Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="font-medium text-sm text-muted-foreground mb-1">Captain</div>
                <div className="font-mono text-lg">{flight.crew.pilot}</div>
              </div>
              <div>
                <div className="font-medium text-sm text-muted-foreground mb-1">First Officer</div>
                <div className="font-mono text-lg">{flight.crew.coPilot}</div>
              </div>
              <div>
                <div className="font-medium text-sm text-muted-foreground mb-1">Flight Attendants</div>
                <div className="font-mono text-lg">{flight.crew.flightAttendants} crew members</div>
              </div>
            </CardContent>
          </Card>

          <Card className="flight-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>Flight Details</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="font-medium text-sm text-muted-foreground mb-1">Passengers</div>
                <div className="font-mono text-lg">{flight.passengers} total</div>
              </div>
              <div>
                <div className="font-medium text-sm text-muted-foreground mb-1">Fuel Remaining</div>
                <div className="font-mono text-lg">{flight.fuelRemaining}</div>
              </div>
              <div>
                <div className="font-medium text-sm text-muted-foreground mb-1">Current Position</div>
                <div className="font-mono text-sm">
                  {flight.coordinates.lat.toFixed(4)}°N, {Math.abs(flight.coordinates.lng).toFixed(4)}°W
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FlightDetail;