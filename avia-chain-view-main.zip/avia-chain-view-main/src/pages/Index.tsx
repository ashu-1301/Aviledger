import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Shield, Users, Eye } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary-glow rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">AviLedger</h1>
                <p className="text-xs text-muted-foreground">Blockchain Aviation Tracking</p>
              </div>
            </div>
            <div className="text-xs text-muted-foreground">
              Secure • Immutable • Real-time
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
              Aviation Data Integrity System
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Secure flight tracking and monitoring with blockchain-powered data integrity. 
              Access real-time flight data with role-based permissions.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Authority Login */}
            <Card className="flight-card group cursor-pointer" onClick={() => navigate('/login/authority')}>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary/20 transition-colors">
                  <Shield className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Authority Access</h3>
                <p className="text-muted-foreground mb-6 text-sm">
                  Full system access with data modification privileges. Monitor and manage all flight operations.
                </p>
                <Button variant="outline" className="w-full">
                  Authority Login
                </Button>
              </CardContent>
            </Card>

            {/* Employee Login */}
            <Card className="flight-card group cursor-pointer" onClick={() => navigate('/login/employee')}>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-accent/50 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-accent/70 transition-colors">
                  <Users className="w-8 h-8 text-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Employee Access</h3>
                <p className="text-muted-foreground mb-6 text-sm">
                  Read-only access to flight data and monitoring systems. View real-time flight information.
                </p>
                <Button variant="secondary" className="w-full">
                  Employee Login
                </Button>
              </CardContent>
            </Card>

            {/* Public Access */}
            <Card className="flight-card group cursor-pointer" onClick={() => navigate('/login/public')}>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-muted/80 transition-colors">
                  <Eye className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Public Access</h3>
                <p className="text-muted-foreground mb-6 text-sm">
                  Basic flight status information. Check flight schedules and general aviation data.
                </p>
                <Button variant="ghost" className="w-full">
                  Public Access
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <div className="inline-flex items-center space-x-2 text-xs text-muted-foreground bg-card/30 px-4 py-2 rounded-full">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
              <span>System Online • Blockchain Verified • Data Integrity Protected</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;