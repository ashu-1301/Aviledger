import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plane, Users, Clock, MapPin } from "lucide-react";

interface FlightData {
  flightNumber: string;
  aircraft: string;
  route: {
    from: string;
    to: string;
  };
  status: 'normal' | 'warning' | 'critical';
  altitude: number;
  speed: number;
  engineTemp: number;
  passengers: number;
  crew: {
    pilot: string;
    coPilot: string;
    flightAttendants: number;
  };
  estimatedArrival: string;
}

interface FlightCardProps {
  flight: FlightData;
  onClick?: () => void;
  showDetails?: boolean;
}

const FlightCard = ({ flight, onClick, showDetails = false }: FlightCardProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical': return 'status-critical';
      case 'warning': return 'status-warning';
      default: return 'status-normal';
    }
  };

  const getMetricStatus = (type: string, value: number) => {
    switch (type) {
      case 'altitude':
        return value < 10000 ? 'critical' : value < 15000 ? 'warning' : 'normal';
      case 'speed':
        return value > 900 ? 'critical' : value > 800 ? 'warning' : 'normal';
      case 'engineTemp':
        return value > 800 ? 'critical' : value > 700 ? 'warning' : 'normal';
      default:
        return 'normal';
    }
  };

  return (
    <Card className={`flight-card cursor-pointer ${onClick ? 'hover:scale-[1.02]' : ''}`} onClick={onClick}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Plane className="w-5 h-5 text-primary" />
            <span className="font-mono">{flight.flightNumber}</span>
          </CardTitle>
          <Badge className={`px-3 py-1 ${getStatusColor(flight.status)} border`}>
            {flight.status.toUpperCase()}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">{flight.aircraft}</p>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Route */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-2">
            <MapPin className="w-4 h-4 text-muted-foreground" />
            <span className="font-medium">{flight.route.from}</span>
          </div>
          <div className="flex-1 mx-3 border-t border-dashed border-border"></div>
          <div className="flex items-center space-x-2">
            <span className="font-medium">{flight.route.to}</span>
            <MapPin className="w-4 h-4 text-muted-foreground" />
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center">
            <div className={`data-metric ${getStatusColor(getMetricStatus('altitude', flight.altitude))}`}>
              {flight.altitude.toLocaleString()}
            </div>
            <div className="data-label">Altitude (ft)</div>
          </div>
          <div className="text-center">
            <div className={`data-metric ${getStatusColor(getMetricStatus('speed', flight.speed))}`}>
              {flight.speed}
            </div>
            <div className="data-label">Speed (mph)</div>
          </div>
          <div className="text-center">
            <div className={`data-metric ${getStatusColor(getMetricStatus('engineTemp', flight.engineTemp))}`}>
              {flight.engineTemp}°
            </div>
            <div className="data-label">Engine Temp</div>
          </div>
        </div>

        {showDetails && (
          <>
            {/* Crew and Passengers */}
            <div className="grid grid-cols-2 gap-4 pt-3 border-t border-border/30">
              <div>
                <div className="flex items-center space-x-1 mb-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Crew</span>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>Pilot: {flight.crew.pilot}</div>
                  <div>Co-Pilot: {flight.crew.coPilot}</div>
                  <div>Attendants: {flight.crew.flightAttendants}</div>
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-1 mb-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Details</span>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>Passengers: {flight.passengers}</div>
                  <div>ETA: {flight.estimatedArrival}</div>
                </div>
              </div>
            </div>
          </>
        )}

        {!showDetails && (
          <div className="flex items-center justify-between pt-2 border-t border-border/30">
            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <Users className="w-3 h-3" />
              <span>{flight.passengers} passengers</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>{flight.estimatedArrival}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FlightCard;